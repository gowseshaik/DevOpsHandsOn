echo example for for loop

for i in `find . -name "*a*"`
do
 echo i value is : $i
done
