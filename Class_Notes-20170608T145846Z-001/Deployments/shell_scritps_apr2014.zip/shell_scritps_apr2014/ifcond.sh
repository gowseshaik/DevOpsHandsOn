echo example for if condition

#echo enter a value:
#read a
#echo enter b value:
#read b

#if [ $a -le $b ]
#then
#  echo $a is smaller
#else
#  echo $b is smaller
#fi
echo enter string
read str
if [ $str == "Hello" ]
then
 echo $str is equal
fi

if [ $str != "Hai" ]
then
 echo $str is not equal
fi

