echo example for case sttmt
#echo enter a
#read a
#echo enter b
#read b
#echo enter operation
#read op

a=$1
b=$2
op=$3

if [ $# -eq 3 ]
then

case $op in

add)  echo Am inside the add case 
	c=$(($a + $b));;
sub)  echo Am inside the sub case
	c=$(($a - $b));;
mul)  echo Am inside the mul case 
	c=$(($a * $b));;
*)    echo Wrong operator ;;
esac

echo c value is : $c

else

  echo You entered wrong no of params 
  echo "USGAE: sh case.sh <param1> <param2> <operation>"
fi
