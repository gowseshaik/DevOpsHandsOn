echo enter file/dir path

if [ -d $1 ]
then

  echo Given is a dir : $1

fi
