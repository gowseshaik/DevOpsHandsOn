echo Hi this is my firt script

a=10
b=20

echo a value: $a
echo b value: $b

c=`expr $a \* $b`

echo c value is  $c
