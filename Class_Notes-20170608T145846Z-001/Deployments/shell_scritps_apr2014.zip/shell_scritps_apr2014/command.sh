echo Example fot command line parama

echo Dollar Star : $*
echo Dollat @    : $@
echo "Dollat #    : $#"
cho Dollar Dollar: @$6$
echo Dollar Dollar: $?



echo First param : $1
echo Second param: $2
