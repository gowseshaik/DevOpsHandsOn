echo Nested if example

echo enter a value
read a
echo enter b value
read b
echo enter operation
read op


if [ $op == "add" ]
then
   c=`expr $a + $b`
elif [ $op == "sub" ]
then
   c=`expr $a - $b`
elif [ $op == "mul" ]
then
   c=$(($a * $b))
else
  echo Wrong operator
fi

echo c value is : $c
