echo While loop exmaple
i=2
while [ $i -le 10 ]
do
 echo $i
 i=`expr $i + 2`
done
