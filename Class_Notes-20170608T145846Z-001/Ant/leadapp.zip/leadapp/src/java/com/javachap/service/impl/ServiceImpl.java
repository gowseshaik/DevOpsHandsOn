package com.javachap.service.impl;

import com.javachap.service.Service;

/**
 * @author Varma
 */

public abstract class ServiceImpl implements Service {

	private static final long serialVersionUID = 7599134799116366251L;

}
